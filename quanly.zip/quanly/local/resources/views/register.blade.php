<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<title>Tạo tài khoản</title>
	
	<!-- customer-css-link -->
	<link rel="stylesheet" href="{{asset('css/registerStyle.css')}}">
	<!-- bootstrap-css-link -->
	<link rel="stylesheet" href="{{asset('library/bootstrap/css/bootstrap.min.css')}}">
	
</head>

<body>
	<div class="container">
		<div class="form-register col-sm-4 offset-sm-4" >
			<form action="{{URL::action('userController@fixUserRegister')}}" method="POST">
				   {{ csrf_field() }}
				<div class="form-group">
					<center> <img src="{{asset('library/photo/adduser.png')}}" width="100px;"> </center>
					<br>
				</div>
					<div class="form-group">
						<input type="text" name="nameUser" id="nameUser" placeholder="Tên truy cập" class="form-control">
					</div>
					<div class="form-group">
						<input type="password" name="passwordUser" id="passwordUser" placeholder="Mật khẩu" class="form-control">
					</div>	
					<div class="form-group">
						<input type="email" name="emailUser" id="emailUser" placeholder="Email" class="form-control">
					</div>	
					<div class="form-group">
						<input type="text" name="levelUser" id="levelUser" value="1" hidden="hidden">
					</div>		
					<div class="form-check">
						<input type="checkbox" checked="checked" class="form-check-input" id="checkLicense">
						<label class="form-check-label" for="exampleCheck1">Đồng ý với <a href="#" id="linkLicense">Các điều khoản</a></label>
					</div>
					<button id="btnRegister" type="submit" class="btn btn-success">Tạo tài khoản</button>	
				</form>
				<div id="other-link">
					<label id="labelLogin" for="linkLogin">Đã có tài khoản? <a id="linkLogin" href="login">Đăng nhập</a></label>
				</div>
			</div>
		</div>
	</body>
	</html>