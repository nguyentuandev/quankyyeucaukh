<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view('welcome');
});

Route::get('register', 'userController@createUser');
Route::post('register', 'userController@fixUserRegister');

Route::get('login', 'userController@loginUser');
Route::post('login', 'userController@fixUserLogin');

Route::get('check', function() {
	return view('index');
});

Route::get('update', 'dataController@updateData');
