

<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8">
	<title>Trang quản lý</title>
	<!-- customer-css-link -->
	<link rel="stylesheet" href="<?php echo e(asset('css/indexStyle.css')); ?>">
	<!-- bootstrap-css-link -->
	<link rel="stylesheet" href="<?php echo e(asset('library/bootstrap/css/bootstrap.min.css')); ?>">

</head>
<body>
	<div class="container-fluid">
		<div class="row">
			<div class="col-sm-2">
					<a href="#" class="btn btn-outline-info"><span class="iconic iconic-plus" title="plus" aria-hidden="true"></span> SOẠN THƯ</a>
			</div>
			<div class="col-sm-10">
				<table class="table">
					<thead class="thead-dark">
						<tr>
							<th scope="col"><input type="checkbox" id="checkAll" name="checkAll"></th>
							<th scope="col">Stt</th>
							<th scope="col">Họ và Tên</th>
							<th scope="col">Số điện thoại</th>
							<th scope="col">Email</th>
							<th scope="col">Địa chỉ</th>
							<th scope="col">Tag</th>
						</tr>
					</thead>
					<tbody>
						
					</tbody>
				</table>
				
			</div>	
		</div>
	</div>
</div>
</body>
</html>