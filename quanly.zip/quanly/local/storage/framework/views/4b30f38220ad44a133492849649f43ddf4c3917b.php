<!DOCTYPE html>
<html>
<head>
	<title>Đăng nhập</title>
	
	<!-- customer-css-link -->
	<link rel="stylesheet" href="<?php echo e(asset('css/loginStyle.css')); ?>">
	<!-- bootstrap-css-link -->
	<link rel="stylesheet" href="<?php echo e(asset('library/bootstrap/css/bootstrap.min.css')); ?>">
	<!-- iconic-css-link -->
	<link rel="stylesheet" href="<?php echo e(asset('library/iconic/fonts/css/open-iconic-bootstrap.min.css')); ?>">
	
</head>

<body>
	<div class="container">
		<div class="form-login col-sm-4 offset-sm-4" >
			<form action="<?php echo e(URL::action('userController@fixUserLogin')); ?>" method="POST">
				<div class="form-group">
					<center> <img src="<?php echo e(asset('library/photo/user.png')); ?>" width="100px;"> </center>
					<br>
				</div>

				<div class="form-group">
					<input type="text" name="userName" id="userName" value="<?php echo e(old('userName')); ?>" placeholder="Tên truy cập" class="form-control">
					<?php if($errors->has('userName')): ?>
							<p style="color:red; font-size: 13px"><?php echo e($errors->first('userName')); ?></p>
					<?php endif; ?>
				</div>

				<div class="form-group">
					<input type="password" name="passwordUser" id="passwordUser" placeholder="Mật khẩu" class="form-control">
					<?php if($errors->has('passwordUser')): ?>
							<p style="color:red; font-size: 13px;"><?php echo e($errors->first('passwordUser')); ?></p>
					<?php endif; ?>
				</div>		

				<?php echo e(csrf_field()); ?>	
				<button id="btnLogin" type="submit" class="btn btn-primary">Đăng nhập</button>	
			</form>
			<div id="other-link">
				<label id="labelRegister" for="linkRegister">Chưa có tài khoản? <a id="linkRegister" href="register">Đăng ký</a></label>
				<a id="linkForgetPassword" href="#">Quên mật khẩu</a>
			</div>
		</div>
	</div>

	
</body>
</html>