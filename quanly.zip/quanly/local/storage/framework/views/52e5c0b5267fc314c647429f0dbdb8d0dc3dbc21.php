<!DOCTYPE html>
<html>
<head>
	<title>Tạo tài khoản</title>
	
	<!-- customer-css-link -->
	<link rel="stylesheet" href="<?php echo e(asset('css/loginStyle.css')); ?>">
	<!-- bootstrap-css-link -->
	<link rel="stylesheet" href="<?php echo e(asset('library/bootstrap/css/bootstrap.min.css')); ?>">
	
</head>

<body>
	<div class="container">
		<div class="form-login col-sm-4 offset-sm-4" >
			<form action="#" method="POST">
				<div class="form-group">
					<center> <img src="<?php echo e(asset('library/photo/user.png')); ?>" width="100px;"> </center>
					<br>
				</div>
				<div class="form-group">
					<input type="text" name="userName" id="userName" placeholder="Tên truy cập" class="form-control">
				</div>
				<div class="form-group">
					<input type="password" name="passwordUser" id="passwordUser" placeholder="Mật khẩu" class="form-control">
				</div>			
				<button id="btnLogin" type="submit" class="btn btn-primary">Đăng nhập</button>	
			</form>
			<div id="other-link">
				<label id="labelRegister" for="linkRegister">Chưa có tài khoản? <a id="linkRegister" href="register">Đăng ký</a></label>
				<a id="linkForgetPassword" href="#">Quên mật khẩu</a>
			</div>
		</div>
	</div>

	
</body>
</html>