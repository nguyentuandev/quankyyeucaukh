<!DOCTYPE html>
<html>
<head>
	<title>Tạo tài khoản</title>
	
	<!-- customer-css-link -->
	<link rel="stylesheet" href="<?php echo e(asset('css/regStyle.css')); ?>">
	<!-- bootstrap-css-link -->
	<link rel="stylesheet" href="<?php echo e(asset('library/bootstrap/css/bootstrap.min.css')); ?>">
	
</head>

<body>
	<div class="container">
		<div class="form col-sm-4 offset-sm-4" >
			<form action="#" method="POST">
				<div class="form-group">
					<center>
						<img src="<?php echo e(asset('library/photo/adduser.png')); ?>" width="100px;">
					</center>
					<br>
				</div>
				<div class="form-group">
					<input type="text" name="userName" id="userName" placeholder="Tên truy cập" class="form-control">
					<!-- <small  class="error-mess form-text text-muted"> cảnh báo lỗi</small> -->
				</div>
				<div class="form-group">
					<input type="password" name="passwordUser" id="passwordUser" placeholder="Mật khẩu" class="form-control">
					<!-- <small  class="error-mess form-text text-muted"> cảnh báo lỗi</small> -->
				</div>
				<div class="form-group">
					<input type="email" name="emailAddress" id="emailAddress" placeholder="Email" class="form-control">
					<!-- <small  class="error-mess form-text text-muted"> cảnh báo lỗi</small> -->
				</div>
				<div class="form-check text-center">
					<input type="checkbox" class="form-check-input" checked="checked">
					<label class="form-check-label">Đồng ý với <a href="#">Các điều khoản</a></label>
				</div>
				<br>
				<div class="form-group">
					<button type="submit" class="btn btn-success">Tạo tài khoản</button>	
				</div>
					
			</form>
		</div>
	</div>

	
</body>
</html>