<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Welcome</title>
    <!-- customer-css-link -->
    <link rel="stylesheet" href="<?php echo e(asset('css/welcomeStyle.css')); ?>">
    <!-- bootstrap-css-link -->
    <link rel="stylesheet" href="<?php echo e(asset('library/bootstrap/css/bootstrap.min.css')); ?>">
</head>
<body>
    <div class="container">
        <div class="row hello">
            <div class="col-sm-6 offset-sm-3">
                <center>
                    <h3>Chào mừng đến với website!</h3>
                    <hr>
                </center>
            </div>   
        </div>
        <div class="row option">
            <div class="col-sm-4 offset-sm-4">
                <center>
                    <p>Mời bạn lựa chọn các hình thức bên dưới để tiếp tục sự dụng dịch vụ của chúng tôi </p>
                </center>
                <div class="customer-option">
                    <a href="login" class="btn btn-success">Đăng nhập</a>
                    <a href="register" class="btn btn-outline-dark">Tạo tài khoản</a>
                </div>
            </div>
            
        </div>

        <div class="row contact">
            <div class="col-sm-4 offset-sm-4">
                <center>
                   <small><p>Theo dõi và cập nhật tin tức mới nhất của chúng tôi tại:</p></small> 
                </center>
                <div class="col-sm-10 offset-sm-1 contact-option">
                    <a href="https://twitter.com/nguyentuan27797"><img src="<?php echo e(asset('library/photo/twitter.png')); ?>" alt="twitter" width="45px"></a>
                    <a href="https://www.facebook.com/nguyentuan277.dev"><img src="<?php echo e(asset('library/photo/facebook.png')); ?>" alt="facebook" width="45px"></a>
                    <a href="https://www.instagram.com/nguyentuan277/"><img src="<?php echo e(asset('library/photo/instagram.png')); ?>" alt="instagram" width="45px"></a>
                </div>
            </div>
        </div>
        
        
    </div>
</body>
</html>