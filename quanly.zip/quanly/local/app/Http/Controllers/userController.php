<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Auth;
use App\userModel;

class userController extends Controller
{
    public function createUser() {
    	return view('register');
    }

    public function fixUserRegister(Request $request) {
		$user = new userModel;
		$user->username = $request->nameUser;
		$user->password = bcrypt($request->passwordUser);
		$user->email = $request->emailUser;
		$user->level = $request->levelUser;

		$user->save();
		return redirect('login');
    }

    public function loginUser() {
    	return view('login');
    }

    public function fixUserLogin (Request $request) {
        
        $username = $request->input('userName');
        $password = $request->input('passwordUser');
        if(Auth::attempt(['username'=>$username, 'password'=>$password])) {


            return redirect()->intended('/');
            // return redirect('welcome');
        }
    }
}
