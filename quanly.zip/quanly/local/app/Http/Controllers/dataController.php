<?php

namespace App\Http\Controllers;
use Illuminate\Http\Request;
use App\dataModel;
use quickstart;


class dataController extends Controller
{
	public function updateData(Request $request) {
			$data = new dataModel;
			$data->fullname = $request->row[1];
			$data->email = $request->row[3];
			$data->phone = $request->row[2];
			$data->address = $request->row[4];
			$data->tag = $request->row[5];
			$data->save();
	}
}
